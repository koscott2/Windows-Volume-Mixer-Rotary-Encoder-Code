var searchData=
[
  ['interval_39',['interval',['../class_debouncer.html#a930bf3945e698d77b889f6309079857d',1,'Debouncer']]],
  ['ispressed_40',['isPressed',['../class_bounce2_1_1_button.html#a73c7c9ef574afe8bf1a9f3eb492bfa7f',1,'Bounce2::Button']]]
];
